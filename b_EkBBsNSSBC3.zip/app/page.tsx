"use client"

import { useState, useRef, useCallback } from "react"
import { Heart, Upload, ImageIcon, X, Loader2, Check } from "lucide-react"

type UploadStatus = "idle" | "uploading" | "success" | "error"

interface FloatingHeart {
  id: number
  left: number
  delay: number
  duration: number
  size: number
}

export default function NuestrosInstantes() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [status, setStatus] = useState<UploadStatus>("idle")
  const [floatingHearts, setFloatingHearts] = useState<FloatingHeart[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = useCallback((file: File) => {
    if (file && file.type.startsWith("image/")) {
      setSelectedFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setPreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
      setStatus("idle")
    }
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)
      const file = e.dataTransfer.files[0]
      if (file) handleFileSelect(file)
    },
    [handleFileSelect]
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (file) handleFileSelect(file)
    },
    [handleFileSelect]
  )

  const clearSelection = useCallback(() => {
    setSelectedFile(null)
    setPreview(null)
    setStatus("idle")
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }, [])

  const triggerFloatingHearts = useCallback(() => {
    const hearts: FloatingHeart[] = Array.from({ length: 12 }, (_, i) => ({
      id: Date.now() + i,
      left: Math.random() * 100,
      delay: Math.random() * 0.5,
      duration: 2 + Math.random() * 2,
      size: 12 + Math.random() * 16,
    }))
    setFloatingHearts(hearts)
    setTimeout(() => setFloatingHearts([]), 4500)
  }, [])

  const handleSubmit = async () => {
    if (!selectedFile) return

    setStatus("uploading")

    const formData = new FormData()
    formData.append("image", selectedFile)

    try {
      const response = await fetch("https://unpainfully-motivational-deidre.ngrok-free.dev/webhook/4928a2e2-ae53-4f61-a979-4a9ec9503ee6", {
        method: "POST",
        body: formData,
      })

      if (response.ok) {
        setStatus("success")
        triggerFloatingHearts()
        setTimeout(() => {
          clearSelection()
        }, 3000)
      } else {
        setStatus("error")
      }
    } catch {
      setStatus("error")
    }
  }

  return (
    <main className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-12 relative overflow-hidden">
      {/* Subtle background hearts */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03]">
        <Heart className="absolute top-[10%] left-[15%] w-24 h-24 text-primary fill-primary" />
        <Heart className="absolute top-[60%] right-[10%] w-16 h-16 text-primary fill-primary" />
        <Heart className="absolute bottom-[20%] left-[8%] w-12 h-12 text-primary fill-primary" />
        <Heart className="absolute top-[30%] right-[20%] w-20 h-20 text-primary fill-primary" />
      </div>

      {/* Floating hearts animation */}
      {floatingHearts.map((heart) => (
        <Heart
          key={heart.id}
          className="absolute text-primary fill-primary animate-float-up pointer-events-none"
          style={{
            left: `${heart.left}%`,
            bottom: 0,
            width: heart.size,
            height: heart.size,
            animationDelay: `${heart.delay}s`,
            animationDuration: `${heart.duration}s`,
            opacity: 0.7,
          }}
        />
      ))}

      {/* Main content */}
      <div className="w-full max-w-md relative z-10">
        {/* Title */}
        <div className="text-center mb-10">
          <div className="flex items-center justify-center gap-3 mb-3">
            <Heart className="w-5 h-5 text-primary fill-primary opacity-60" />
            <Heart className="w-4 h-4 text-primary fill-primary opacity-40" />
          </div>
          <h1 className="font-serif text-4xl md:text-5xl text-foreground tracking-tight mb-3">
            Nuestros Instantes
          </h1>
          <p className="text-muted-foreground text-sm tracking-wide">
            Un rincón para nuestros recuerdos
          </p>
        </div>

        {/* Upload Card */}
        <div className="bg-card rounded-3xl shadow-sm border border-border p-6 md:p-8">
          {/* Drop Zone */}
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onClick={() => !preview && fileInputRef.current?.click()}
            className={`
              relative rounded-2xl border-2 border-dashed transition-all duration-300 ease-out
              ${preview ? "border-transparent" : "cursor-pointer"}
              ${
                isDragging
                  ? "border-primary bg-accent/50 scale-[1.02]"
                  : "border-border hover:border-primary/50 hover:bg-muted/50"
              }
              ${!preview ? "min-h-[280px]" : ""}
            `}
          >
            {preview ? (
              <div className="relative">
                <img
                  src={preview}
                  alt="Vista previa"
                  className="w-full h-auto rounded-2xl object-cover max-h-[400px]"
                />
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    clearSelection()
                  }}
                  className="absolute top-3 right-3 bg-foreground/80 text-card rounded-full p-2 hover:bg-foreground transition-colors shadow-lg"
                  aria-label="Eliminar imagen"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full min-h-[280px] p-8">
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                  {isDragging ? (
                    <Upload className="w-7 h-7 text-primary animate-bounce" />
                  ) : (
                    <ImageIcon className="w-7 h-7 text-muted-foreground" />
                  )}
                </div>
                <p className="text-foreground font-medium mb-1">
                  {isDragging ? "Suelta aquí tu recuerdo" : "Arrastra una foto"}
                </p>
                <p className="text-muted-foreground text-sm">
                  o haz clic para seleccionar
                </p>
                <div className="flex items-center gap-1.5 mt-4 text-primary/60">
                  <Heart className="w-3 h-3 fill-current" />
                  <span className="text-xs">JPG, PNG, WEBP</span>
                  <Heart className="w-3 h-3 fill-current" />
                </div>
              </div>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleInputChange}
            className="hidden"
          />

          {/* Submit Button */}
          <button
            onClick={handleSubmit}
            disabled={!selectedFile || status === "uploading" || status === "success"}
            className={`
              w-full mt-6 py-4 px-6 rounded-2xl font-medium text-sm tracking-wide
              transition-all duration-300 ease-out
              flex items-center justify-center gap-2
              ${
                status === "success"
                  ? "bg-green-100 text-green-700 border border-green-200"
                  : status === "error"
                  ? "bg-red-50 text-red-600 border border-red-200"
                  : selectedFile
                  ? "bg-primary text-primary-foreground hover:shadow-md hover:scale-[1.02] active:scale-[0.98]"
                  : "bg-muted text-muted-foreground cursor-not-allowed"
              }
            `}
          >
            {status === "uploading" ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Subiendo...</span>
              </>
            ) : status === "success" ? (
              <>
                <Check className="w-4 h-4" />
                <span>¡Publicado en nuestro amor!</span>
              </>
            ) : status === "error" ? (
              <span>Error al subir. Intenta de nuevo</span>
            ) : (
              <>
                <Heart className="w-4 h-4" />
                <span>Publicar nuestro recuerdo</span>
              </>
            )}
          </button>

          {/* Status message */}
          {status === "error" && (
            <p className="text-center text-xs text-red-500 mt-3">
              No se pudo conectar con el servidor. Verifica la URL del webhook.
            </p>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-center gap-2 mt-8 text-muted-foreground/50">
          <Heart className="w-3 h-3 fill-current" />
          <span className="text-xs tracking-widest uppercase">Solo nosotros</span>
          <Heart className="w-3 h-3 fill-current" />
        </div>
      </div>

      {/* CSS for floating animation */}
      <style jsx global>{`
        @keyframes float-up {
          0% {
            transform: translateY(0) rotate(0deg);
            opacity: 0.7;
          }
          50% {
            opacity: 1;
          }
          100% {
            transform: translateY(-100vh) rotate(45deg);
            opacity: 0;
          }
        }
        .animate-float-up {
          animation: float-up linear forwards;
        }
      `}</style>
    </main>
  )
}
